db.createCollection("users")
db.createCollection("roles")
db.createCollection("sessions")
db.createCollection("customers")
